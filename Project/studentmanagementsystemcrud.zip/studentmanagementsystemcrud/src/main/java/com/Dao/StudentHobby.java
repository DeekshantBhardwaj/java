package com.Dao;

import jakarta.persistence.*;

@Entity
@Table(name="Student_Hobby")
public class StudentHobby {
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	private int hId;
	private String Age;
	
	public int gethId() {
		return hId;
	}
	public void sethId(int hId) {
		this.hId = hId;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String age) {
		Age = age;
	}



@Override
public String toString() {
	return "StudentHobby [hId=" + hId + ", Age=" + Age + "]";
}
{
	// TODO Auto-generated method stub
	
}
}