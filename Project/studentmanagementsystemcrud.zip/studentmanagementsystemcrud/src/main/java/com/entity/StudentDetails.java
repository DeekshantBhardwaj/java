package com.entity;
import com.Dao.StudentHobby;

import jakarta.persistence.*;

@Entity
	@Table(name="Student_Details")
	public class StudentDetails 
	{

		@Id @GeneratedValue(strategy=GenerationType.AUTO)
		private int userid;
		private String StudentName;
		private String LastName;
		
		
		@OneToOne
		@JoinColumn(name="hId")
		private StudentHobby studenthobby;
		
		
		public StudentHobby getStudenthobby() {
			return studenthobby;
		}


		public void setStudenthobby(StudentHobby studenthobby) {
			this.studenthobby = studenthobby;
		}



		
		public int getUserid() {
			return userid;
		}
		public void setUserid(int userid) {
			this.userid = userid;
		}
		public String getStudentName() {
			return StudentName;
		}
		public void setStudentName(String studentName) {
			StudentName = studentName;
		}
		private String checkStudent(String string)
		{
			return "Deekshant" ;
		}
		public String getLastName() {
			return LastName;
		}
		public void setLastName(String lastName) {
			LastName = lastName;
		}
		@Override
		public String toString() {
			return "StudentDetails [userid=" + userid + ", StudentName=" + StudentName + ", LastName=" + LastName + "]";
		}
	}
		


