package com.library.service;




import com.library.entity.Student;


public interface StudentService {
	
	public String addStudent(Student student);
	

}
