package com.student_management_system_crud.studentmanagementsystemcrud;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.Dao.StudentHobby;
import com.entity.StudentDetails;


public class App 
{
    public static void main( String[] args )
    {
        StudentDetails Sd= new StudentDetails();
        Sd.setStudentName("Deekshant");
        Sd.setLastName("Bhardwaj");
        
        StudentHobby Sh= new StudentHobby();
         Sh.setAge("22");
         Sd.setStudenthobby(Sh);
        SessionFactory sessionFactory= new Configuration().configure().buildSessionFactory();        		
        Session session =sessionFactory.openSession();
        session.beginTransaction();
        session.save(Sd);
        session.save(Sh);
        session.getTransaction().commit();
    }
}
