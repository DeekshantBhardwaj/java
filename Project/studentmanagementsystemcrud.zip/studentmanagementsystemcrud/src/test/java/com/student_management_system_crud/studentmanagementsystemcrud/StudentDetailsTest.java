package com.student_management_system_crud.studentmanagementsystemcrud;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class StudentDetailsTest {
	private StudentDetailsTest studentDetailstest;
	
	 @DisplayName("Test check for Deekshant")
	@Test
	public void Studenttest() 
	{
		assertEquals(false,StudentDetailsTest.class);
	}

	//private Object checkStudentName(String string) {
		// TODO Auto-generated method stub
		//return null;
	

}
